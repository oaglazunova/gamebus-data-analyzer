# Engagement Calculation and Visualization in TU/e Samen Gezond '21a

This document explains how engagement is calculated and visualized in the TU/e Samen Gezond '21a study.

## How Engagement is Calculated

In this study, engagement is measured in two main ways:

### 1. Passive Engagement

Passive engagement is measured by the variable `donline` (days online), which represents the number of days a user checked the app during a specific time period (wave). This is calculated in the data extraction process by counting the distinct dates when a user accessed the app:

```sql
COUNT(DISTINCT IF(api.`request_uri` LIKE '%/gis/locations', NULL, CAST(api.`date` AS DATE))) AS 'donline'
```

This SQL query counts the number of distinct days a user accessed the app, excluding location tracking requests.

### 2. Active Engagement

Active engagement is measured by the variable `ractivities` (rewarded activities), which represents the number of activities a user completed that were rewarded with points. This is calculated in the data extraction process as:

```sql
SUM(points > 0) AS 'ractivities'
```

This SQL query counts the number of activities that earned points (points > 0).

### User Types

Based on these engagement metrics, users are classified into different types:
- **Passive Users**: Users who checked the app at least once (`donline > 0`) but did not complete any rewarded activities (`ractivities = 0`)
- **Active Users**: Users who completed at least one rewarded activity (`ractivities > 0`)

This classification is done in the R code:

```r
agg$utype <- 0
agg[agg$donline > 0,]$utype <- 1
agg[agg$ractivities > 0,]$utype <- 2
agg$utype <- factor(agg$utype, levels=c(0, 1, 2), labels=c(NA, 'Passive', 'Active'))
```

## Engagement Visualizations

The study includes several visualizations of engagement:

### 1. Passive Engagement Visualizations

#### Days Online by Treatment Group
This visualization shows the average number of days online per week for each treatment group:

```r
ggline(df, x='waveo', y='donline', color='treatment',
       add=c('mean_se'), ylim=c(0, 6),
       palette=paletteSA,
       ylab='Number of Days Online', xlab='Week (ordinal)',
       legend.title='Reinforcement schedule') +
  theme(text=element_text(family='serif'))
```

This creates a line graph showing how passive engagement (days online) changes over time for different treatment groups.

#### Days Online by User Performance
This visualization shows the average number of days online per week for users who won a voucher versus those who didn't:

```r
ggline(df, x='waveo', y='donline', color='wonvoucher',
       add=c('mean_se'), ylim=c(0, 8),
       palette=paletteUT,
       ylab='Number of Days Online', xlab='Week (ordinal)',
       legend.title='User performance') +
  theme(text=element_text(family='serif'))
```

### 2. Active Engagement Visualizations

#### Rewarded Activities by Treatment Group
This visualization shows the average number of rewarded activities per week for each treatment group, focusing on active users:

```r
ggline(subset(df, (utype == 'Active')), x='waveo', y='ractivities', color='treatment',
       add=c('mean_se'), ylim=c(0, 15),
       palette=paletteSA,
       ylab='Number of Rewarded Activities', xlab='Week (ordinal)',
       legend.title='Reinforcement schedule') +
  theme(text=element_text(family='serif'))
```

#### Rewarded Activities by User Performance
This visualization shows the average number of rewarded activities per week for active users who won a voucher versus those who didn't:

```r
ggline(subset(df, (utype == 'Active')), x='waveo', y='ractivities', color='wonvoucher',
       add=c('mean_se'), ylim=c(0, 20),
       palette=paletteUT,
       ylab='Number of Rewarded Activities', xlab='Week (ordinal)',
       legend.title='User performance') +
  theme(text=element_text(family='serif'))
```

### 3. Dropout Analysis

The study also includes a visualization of participant dropout over time:

```r
ggplot() + geom_step(samplesize, mapping=aes(x=wave, y=total)) +
  theme_minimal() +
  theme(panel.grid.major.x = element_blank()) +
  ylab('Number of participants that checked the app at least once') +
  scale_x_continuous('Week (ordinal)', breaks=samplesize$wave + .5,
                     labels=samplesize$wave, limits = c(0, max(samplesize$wave))) + 
  coord_cartesian(xlim=c(1, max(samplesize$wave) - .25)) +
  
  geom_text(aes(x=samplesize$wave, y=samplesize$total,
            label=paste('-', samplesize$lost, sep = ''), family='serif'), size=3.8,
            nudge_x=.5, nudge_y=-1, color='#ff7675') +
  geom_text(aes(x=samplesize$wave, y=samplesize$total,
            label=paste('+', samplesize$new, sep = ''), family='serif'), size=3.8,
            nudge_x=.3, nudge_y=1, color='#1dd1a1') +
  geom_text(aes(x=samplesize$wave, y=samplesize$total,
            label=paste('+', samplesize$regained, sep = ''), family='serif'), size=3.8,
            nudge_x=.7, nudge_y=1, color='#feca57')
```

This visualization shows the total number of participants over time, with annotations for lost, new, and regained participants.

## Statistical Analysis of Engagement

The study includes statistical analyses of engagement using hierarchical linear models:

### Passive Engagement Analysis
```r
lmer.doa <- lmer(formula = sqrt(donline) ~ waveo + (1 | uid), data=df)
```

### Active Engagement Analysis
```r
lmer.raa <- lmer(formula = sqrt(ractivities) ~ waveo + (1 | uid), data=subset(df, (utype == 'Active')))
```

These models analyze how engagement changes over time, accounting for individual differences by including a random effect for user ID.

## Potential Additional Engagement Visualizations

Some additional visualizations that could be useful for understanding engagement:

1. **Heatmap of engagement by day of week and time of day** - This would show when users are most active
2. **Engagement distribution** - Histograms showing the distribution of days online and rewarded activities
3. **Engagement correlation with health impact** - Scatter plots showing the relationship between engagement metrics and perceived health impact
4. **Engagement patterns by demographic characteristics** - Visualizations showing how engagement varies by age, gender, and affiliation