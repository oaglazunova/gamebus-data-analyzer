import pandas as pd
import mysql.connector
import json
import re

def query(q):
    connection = mysql.connector.connect(
      user='gamebus_user',
      password='LuMgyCADxV',
      host='127.0.0.1',
      database='gamebus_api',
      port=3306
    )
    return pd.read_sql_query(q, connection)


campaign = {
    'name': '21-tuesg',
    'start': '2021-02-01 05:00:00',
    'end': '2021-03-15 04:59:59',
    'circles': [102935],
    'admins': [104126, 100478, 100023, 103950, 103636, 103985, 102017, 103729, 103793], # Admin, RN, PVG, Dominique, Alireza, Amirreza, Melissa, Yassaman, Sam
    'treatments': [102936, 102937, 102964],
    'waves': {
        '1': {
            'start': '2021-02-01 05:00:00',
            'end': '2021-02-08 04:59:59',
        },
        '2': {
            'start': '2021-02-08 05:00:00',
            'end': '2021-02-15 04:59:59',
        },
        '3': {
            'start': '2021-02-15 05:00:00',
            'end': '2021-02-22 04:59:59',
        },
        '4': {
            'start': '2021-02-22 05:00:00',
            'end': '2021-03-01 04:59:59',
        },
        '5': {
            'start': '2021-03-01 05:00:00',
            'end': '2021-03-08 04:59:59',
        },
        '6': {
            'start': '2021-03-08 05:00:00',
            'end': '2021-03-15 04:59:59',
        },
    }
}



w = 1
W = 6
df = pd.DataFrame()
for wave in range(w, W + 1):
    accounts = getAccounts(campaign, campaign['waves'][str(wave)])
    events = getEvents(campaign, campaign['waves'][str(wave)])
    activities = getActivities(campaign, campaign['waves'][str(wave)])
    resolutions = getResolutions(campaign, campaign['waves'][str(wave)])

    log = pd.merge(accounts, events, on=['uid', 'pid'], how='left')
    log = pd.merge(log, activities, on=['uid', 'pid'], how='left')
    log = pd.merge(log, resolutions, on=['uid'], how='left')
    log.fillna(0, inplace=True)
    log.insert(loc=0, column='wave', value=wave)

    df = df.append(log, ignore_index=True)



df.to_csv('./' + campaign['name'] + '-event-log.csv')







acc = getAccounts(campaign, campaign['waves'][str(6)])
acc.to_csv('./' + campaign['name'] + '-accounts.csv')

survey = parseSurvey()
survey = survey[survey['uid'].notna()]
# survey['uid'] = survey['uid'].replace(uuid, range(1, len(uuid) + 1))
survey.to_csv('./' + campaign['name'] + '-post-test-survey.csv', index=False)



surveypre = parsePreTestSurvey()
surveypre = surveypre[surveypre['uid'].notna()]
# surveypre['uid'] = surveypre['uid'].replace(uuid, range(1, len(uuid) + 1))
surveypre.to_csv('./' + campaign['name'] + '-pre-test-survey.csv', index=False)





df = pd.read_csv('./' + campaign['name'] + '-event-log.csv')
df = df.drop(df.columns[0], axis=1)

# survey = pd.read_csv('./20-bsak-survey.csv', sep=';')
# survey = survey[survey['uid'].notna()]
# df = pd.merge(df, survey, on=['uid'], how='left')

survey = pd.read_csv('./21-tuesg-survey.csv', sep=';')
survey = survey[survey['uid'].notna()]
df = pd.merge(df, survey, on=['uid'], how='left')
# , 'extra', 'agree', 'consc', 'neuro', 'intel', 'personality'


df.to_csv('./' + campaign['name'] + '-data.csv')







# Evaluation of visualization strategy
strategymutations = getVizualizationStrategy(campaign)
strategymutations.to_csv('./' + campaign['name'] + '-visualization-strategies.csv')

strategyupdates = strategymutations.groupby(by='uid').count().reset_index()[['uid', 'strategy']]
strategyupdates.rename(columns={'strategy': 'updates'}, inplace=True)
strategyupdates['switches'] = 0


for uid in list(strategymutations.uid.unique()):
    for i, strategyupdate in enumerate(strategymutations.loc[strategymutations['uid'] == uid].iterrows()):
        strategy = strategyupdate[1].strategy.replace('i-', '')
        if i == 0:
            prevstrategy = strategy
        if strategy != prevstrategy:
            strategyupdates.loc[strategyupdates['uid'] == uid, 'switches'] += 1
        prevstrategy = strategy

preferredstrategy = strategymutations.groupby(by='uid').last().reset_index()[['uid', 'strategy']]
preferredstrategy['strategy'] = preferredstrategy['strategy'].apply(lambda x: 'indifferent' if 'i-' in x else x)
preferredstrategy.rename(columns={'strategy': 'preferred'}, inplace=True)

pd.merge(strategyupdates, preferredstrategy, on=['uid'], how='left').to_csv('./' + campaign['name'] + '-visualization-strategies-agg.csv')


# Start of basic functions

def getAccounts(campaign, dates):
    accounts = query('''SELECT
        user.`id` AS 'uid',
        player.`id` AS 'pid'
        -- , user.`email` AS 'email'
        -- , CONCAT(user.`first_name`, ' ', user.`last_name`) AS 'player'
        FROM user AS user
        LEFT JOIN player AS player ON user.`id` = player.`user`
        LEFT JOIN circle_membership AS membership ON player.`id` = membership.`player_id`
        LEFT JOIN circle AS circle ON membership.`circle_id` = circle.`id`
		WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
		AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        AND membership.`mem_app_date` <= \'''' + dates['end'] + '''\'''')

    treatments = query('''SELECT
        user.`id` AS 'uid',
        player.`id` AS 'pid',
        circle.`name` AS 'treatment'
        FROM user AS user
        LEFT JOIN player AS player ON user.`id` = player.`user`
        LEFT JOIN circle_membership AS membership ON player.`id` = membership.`player_id`
        LEFT JOIN circle AS circle ON membership.`circle_id` = circle.`id`
		WHERE circle.id IN (''' + str(",".join(map(str, campaign['treatments']))) + ''')
		AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        AND membership.`mem_app_date` <= \'''' + dates['end'] + '''\'''')

    accounts = pd.merge(accounts, treatments, on=['uid', 'pid'], how='left')

    return accounts



def getEvents(campaign, dates):
    events = query('''SELECT
        user.`id` AS 'uid',
        player.`id` AS 'pid',

        COUNT(DISTINCT IF(api.`request_uri` LIKE '%/gis/locations', NULL, CAST(api.`date` AS DATE))) AS 'donline',
        COUNT(DISTINCT IF(api.`request_uri` LIKE '%/gis/locations', CAST(api.`date` AS DATE), NULL)) AS 'dtracked',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE CONCAT('/v_/players/', player.`id`, '/activities')
        THEN 1 ELSE NULL END) AS 'vactivities',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/players/%/activities'
        	AND api.`request_uri` NOT LIKE CONCAT('/v_/players/', player.`id`, '/activities')
        THEN 1 ELSE NULL END) AS 'vactivitiesf',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/activities/%'
        	AND api.`request_uri` NOT LIKE '/v_/activities/%/%'
        THEN 1 ELSE NULL END) AS 'vactivity',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/%/circles-activities'
        THEN 1 ELSE NULL END) AS 'vnewsfeed',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE CONCAT('/v_/players/', player.`id`)
        	AND api.`request_uri` NOT LIKE '/v_/players/%/%'
        THEN 1 ELSE NULL END) AS 'vprofile',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/players/%'
        	AND api.`request_uri` NOT LIKE '/v_/players/%/%'
        	AND api.`request_uri` NOT LIKE CONCAT('/v_/players/', player.`id`)
        THEN 1 ELSE NULL END) AS 'vprofilep',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/circles/%'
        	AND api.`request_uri` NOT LIKE '/v_/circles/%/%'
        THEN 1 ELSE NULL END) AS 'vcircle',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/challenges'
        	AND api.`request_uri` NOT LIKE '/v_/challenges/%'
        THEN 1 ELSE NULL END) AS 'vchallenges',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/challenges/%'
        	AND api.`request_uri` NOT LIKE '/v_/challenges/%/%'
        THEN 1 ELSE NULL END) AS 'vleaderboard',

        COUNT(CASE
        	WHEN api.`request_method` = 'GET'
        	AND api.`request_uri` LIKE '/v_/challenges/%/leaderboard/%'
        THEN 1 ELSE NULL END) AS 'vleaderboardc'

        FROM player AS player
        LEFT JOIN user AS user ON player.`user` = user.`id`
        LEFT JOIN api_request AS api ON user.`id` = api.`user`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND api.`date` >= \'''' + dates['start'] + '''\'
        AND api.`date` <= \'''' + dates['end'] + '''\'
        GROUP BY api.`user`, player.`id`''')

    ssupports = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'ssupports',
        COUNT(DISTINCT activity.`player`) AS 'ssupportsup'
        FROM support AS support
        LEFT JOIN game_session AS activity ON support.`game_session` = activity.`id`
        LEFT JOIN player AS player ON support.`supporter` = player.`id`
        LEFT JOIN user AS user ON player.`user` = user.`id`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND support.`supported_at` >= \'''' + dates['start'] + '''\'
        AND support.`supported_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, ssupports, on=['uid'], how='left')

    rsupports = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'rsupports',
        COUNT(DISTINCT support.`supporter`) AS 'rsupportsup'
        FROM support AS support
        LEFT JOIN game_session AS activity ON support.`game_session` = activity.`id`
        LEFT JOIN player AS player ON activity.`player` = player.`id`
        LEFT JOIN user AS user ON player.`user` = user.`id`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND support.`supporter` <> player.`id`
        AND support.`supported_at` >= \'''' + dates['start'] + '''\'
        AND support.`supported_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, rsupports, on=['uid'], how='left')

    sreactions = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'sreactions',
        COUNT(DISTINCT activity.`player`) AS 'sreactionsup'
        FROM message AS message
        LEFT JOIN chat AS chat ON message.`chat` = chat.`id`
        LEFT JOIN game_session AS activity ON chat.`game_session` = activity.`id`
        LEFT JOIN user AS user ON message.`user` = user.`id`
        WHERE activity.`player` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND message.`created_at` >= \'''' + dates['start'] + '''\'
        AND message.`created_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, sreactions, on=['uid'], how='left')

    sreactionss = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'sreactionss'
        FROM message AS message
        LEFT JOIN chat AS chat ON message.`chat` = chat.`id`
        RIGHT JOIN game_session AS activity ON chat.`game_session` = activity.`id`
        LEFT JOIN user AS user ON message.`user` = user.`id`
        LEFT JOIN player AS player ON user.`id` = player.`user`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND activity.`player` = player.`id`
        AND message.`created_at` >= \'''' + dates['start'] + '''\'
        AND message.`created_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, sreactionss, on=['uid'], how='left')

    rreactions = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'rreactions',
        COUNT(DISTINCT message.`user`) AS 'rreactionsup'
        FROM message AS message
        LEFT JOIN chat AS chat ON message.`chat` = chat.`id`
        RIGHT JOIN game_session AS activity ON chat.`game_session` = activity.`id`
        LEFT JOIN player AS player ON activity.`player` = player.`id`
        LEFT JOIN user AS user ON player.`user` = user.`id`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND message.`user` <> user.`id`
        AND message.`created_at` >= \'''' + dates['start'] + '''\'
        AND message.`created_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, rreactions, on=['uid'], how='left')

    smessages = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'smessages',
        COUNT(DISTINCT circle.`id`) AS 'smessagesuc'
        FROM message AS message
        LEFT JOIN chat AS chat ON message.`chat` = chat.`id`
        RIGHT JOIN circle AS circle ON chat.`circle` = circle.`id`
        LEFT JOIN user AS user ON message.`user` = user.`id`
        LEFT JOIN player AS player ON user.`id` = player.`user`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND message.`created_at` >= \'''' + dates['start'] + '''\'
        AND message.`created_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, smessages, on=['uid'], how='left')

    rmessages = query('''SELECT
        user.`id` AS 'uid',
        COUNT(*) AS 'rmessages',
        COUNT(DISTINCT message.`user`) AS 'rmessagesup',
        COUNT(DISTINCT message.`chat`) AS 'rmessagesruc'
        FROM message AS message
        LEFT JOIN chat AS chat ON message.`chat` = chat.`id`
        RIGHT JOIN circle AS circle ON chat.`circle` = circle.`id`
        LEFT JOIN circle_membership AS cm ON circle.`id` = cm.`circle_id`
        LEFT JOIN player AS player ON cm.`player_id` = player.`id`
        LEFT JOIN user AS user ON player.`user` = user.`id`
        WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        	LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        	LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
            WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
            AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND message.`user` <> user.`id`
        AND message.`created_at` >= \'''' + dates['start'] + '''\'
        AND message.`created_at` <= \'''' + dates['end'] + '''\'
        GROUP BY user.`id`''')
    events = pd.merge(events, rmessages, on=['uid'], how='left')

    return events


def getActivities(campaign, dates):
    activities = query('''SELECT
        uid, pid,
        COUNT(DISTINCT aid) AS 'activities',
        COUNT(aactivity) AS 'aactivities',
        SUM(points > 0) AS 'ractivities',
        CASE
            WHEN SUM(points > 0 && aactivity > 0) > 0 THEN SUM(points > 0 && aactivity > 0)
            ELSE 0
        END AS 'raactivities',
        COUNT(DISTINCT IF(challenge > 0, challenge, NULL)) AS 'challenges',
        CASE
            WHEN SUM(points) > 0 THEN SUM(points)
            ELSE 0
        END AS 'points',
        CASE
            WHEN COUNT(DISTINCT rule) > 0 THEN COUNT(DISTINCT rule)
            ELSE 0
        END AS 'urules',
        COUNT(DISTINCT type) AS 'atypes',
        COUNT(DISTINCT IF(points > 0, type, NULL)) AS 'ratypes'
        FROM (
        	SELECT
        	user.`id` AS 'uid',
        	player.`id` AS 'pid',
        	gs.`id` AS 'aid',
        	gd.`translation_key` AS 'type',
        	CASE
        	    WHEN gs.`data_provider` <> 1 THEN 1
        	    ELSE NULL
        	END AS 'aactivity',
        	CASE
        	    WHEN participation.`circle` IS NULL THEN 0
        	    ELSE participation.`circle`
        	END AS 'circle',
        	CASE
        	    WHEN participation.`challenge` IS NULL THEN 0
        	    ELSE participation.`challenge`
        	END AS 'challenge',
        	CASE
        	    WHEN pp.`value` IS NULL THEN 0
        	    ELSE pp.`value`
        	END AS 'points',
        	CASE
        	    WHEN pp.`value` IS NULL THEN NULL
        	    WHEN pp.`value` = 0 THEN NULL
        	    ELSE pp.`challenge_rule`
        	END AS 'rule'
        	FROM game_session AS gs
        	LEFT JOIN game_descriptor AS gd ON gs.`game_descriptor` = gd.`id`
        	LEFT JOIN player AS player ON gs.`player` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
        	LEFT JOIN personal_point AS pp ON gs.`id` = pp.`game_session`
        	LEFT JOIN participation AS participation ON pp.`participation` = participation.`id`
        	WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        		LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        		LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        		LEFT JOIN user AS user ON player.`user` = user.`id`
        		WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
        		AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        	)
            AND gs.`created_at` >= \'''' + dates['start'] + '''\'
            AND gs.`created_at` <= \'''' + dates['end'] + '''\'
            AND gs.`game_descriptor` != 64
        ) AS activity
        GROUP BY activity.`pid`''')

    atypes = query('''SELECT
    uid, pid, ratype,
    COUNT(ratype) AS 'count'
    FROM (
    	SELECT
    	user.`id` AS 'uid',
    	player.`id` AS 'pid',
    	gs.`id` AS 'aid',
    	gs.`created_at` AS 'date',
    	CASE
    	    WHEN gs.`game_descriptor` = 1 THEN 1
    	    ELSE NULL
    	END AS 'raactivity',
    	CASE
    	    WHEN (rule.`name` LIKE '%quick walk%') THEN 'awalk'
    	    WHEN (rule.`name` LIKE '%quick run%') THEN 'arun'
    	    WHEN (rule.`name` LIKE '%quick bike%') THEN 'abike'
    	    WHEN (rule.`name` LIKE '%steps per day%') THEN 'adailysteps'
    	    WHEN (rule.`name` LIKE '%piece of fruit%') THEN 'afruit'
    	    WHEN (rule.`name` LIKE '%moment of the week%') THEN 'amotw'
    	    WHEN (
                rule.`name` LIKE 'BONUS%park%'
                OR rule.`name` LIKE 'BONUS%sandwich%'
                OR rule.`name` LIKE 'BONUS%dog%'
                OR rule.`name` LIKE 'BONUS%salad%'
                OR rule.`name` LIKE 'BONUS%sit-ups%'
            ) THEN 'abonus'
    	    ELSE 'aother'
    	END AS 'ratype'
    	FROM game_session AS gs
    	LEFT JOIN player AS player ON gs.`player` = player.`id`
    	LEFT JOIN user AS user ON player.`user` = user.`id`
    	LEFT JOIN personal_point AS pp ON gs.`id` = pp.`game_session`
    	LEFT JOIN participation AS participation ON pp.`participation` = participation.`id`
    	LEFT JOIN challenge AS challenge ON participation.`challenge` = challenge.`id`
    	LEFT JOIN challenge_rule AS rule ON pp.`challenge_rule` = rule.`id`
    	LEFT JOIN condition_rule AS cond ON rule.`id` = cond.`challenge_rule`
    	WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
    		LEFT JOIN circle_membership AS membersip ON circle.`id` = membersip.`circle_id`
    		LEFT JOIN player AS player ON membersip.`player_id` = player.`id`
    		LEFT JOIN user AS user ON player.`user` = user.`id`
    		WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
    		AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
    	)
        AND gs.`created_at` >= \'''' + dates['start'] + '''\'
        AND gs.`created_at` <= \'''' + dates['end'] + '''\'
    	AND gs.`game_descriptor` != 64
    	AND pp.`value` > 0
    	GROUP BY user.`id`, player.`id`, gs.`id`, rule.`id`
    	ORDER BY gs.`created_at` ASC
    ) AS activity
    GROUP BY activity.`pid`, activity.`ratype`''')

    cols = ['uid', 'awalk', 'arun', 'abike', 'adailysteps', 'afruit', 'amotw', 'abonus', 'aother']
    atypes = atypes.pivot(index='uid', columns='ratype', values='count').reset_index().reindex(columns=cols).fillna(0)

    activities = pd.merge(activities, atypes, on=['uid'], how='left')

    return activities



def getResolutions(campaign, dates):
    resolutions = query('''SELECT
        user.`id` AS 'uid',
        -- challenge.`start_date` AS 'date'
        COUNT(challenge.`id`) AS 'uresolutions'
        FROM challenge AS challenge
        LEFT JOIN user as user ON challenge.`user` = user.`id`
        WHERE user.`id` IN (
        SELECT
        	user.`id` AS 'uid'
        	FROM user AS user
        	LEFT JOIN player AS player ON user.`id` = player.`user`
        	LEFT JOIN circle_membership AS membership ON player.`id` = membership.`player_id`
        	LEFT JOIN circle AS circle ON membership.`circle_id` = circle.`id`
    		WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
    		AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        )
        AND challenge.`name` LIKE 'tuesg21-rules-personal%'
        AND challenge.`start_date` >= \'''' + dates['start'] + '''\'
        AND challenge.`start_date` <= \'''' + dates['end'] + '''\'
        GROUP BY user.id''')
    return resolutions


def getVizualizationStrategy(campaign):
    strategy = query('''SELECT
        uid, pid,
        date,
        strategy,
        properties
        FROM (
        	SELECT
        	user.`id` AS 'uid',
        	player.`id` AS 'pid',
        	gs.`id` AS 'aid',
        	gs.`created_at` AS 'date',
        	gd.`translation_key` AS 'type',
                CAST(
            	GROUP_CONCAT(
        		CASE
        		    WHEN pi.`property` = 1135 THEN pi.`value`
        		    ELSE NULL
        		END
                ) AS CHAR
        	) AS 'strategy',
            CAST(
          	GROUP_CONCAT(
        		CASE
        		    WHEN pi.`property` = 1135 THEN NULL
        		    ELSE pi.`value`
        		END
        	) AS CHAR ) AS 'properties'
        	FROM game_session AS gs
        	LEFT JOIN game_descriptor AS gd ON gs.`game_descriptor` = gd.`id`
        	LEFT JOIN player AS player ON gs.`player` = player.`id`
        	LEFT JOIN user AS user ON player.`user` = user.`id`
        	LEFT JOIN property_instance AS pi ON gs.`id` = pi.`game_session`

        	WHERE player.`id` IN (SELECT DISTINCT player.`id` AS 'pid' FROM circle AS circle
        		LEFT JOIN circle_membership AS membership ON circle.`id` = membership.`circle_id`
        		LEFT JOIN player AS player ON membership.`player_id` = player.`id`
        		LEFT JOIN user AS user ON player.`user` = user.`id`
        		WHERE circle.id IN (''' + str(",".join(map(str, campaign['circles']))) + ''')
        		AND user.`id` NOT IN (''' + str(",".join(map(str, campaign['admins']))) + ''')
        	)
            AND gs.`created_at` >= \'''' + campaign['start'] + '''\'
            AND gs.`created_at` <= \'''' + campaign['end'] + '''\'
        	AND gs.`game_descriptor` = 1076
        	GROUP BY gs.`id`
        ) AS activity
        GROUP BY aid
        ORDER BY date ASC''')
    return strategy


def parsePreTestSurvey():
    pre = pd.read_csv('./survey/21-tuesg-pre-test-survey.csv', sep=',')
    pre = pre.rename(columns = {'Respondent ID': 'rid'})
    premap = pd.read_csv('./survey/mapping-pre-test-survey-account.csv', sep=',')

    pre = pd.merge(pre, premap, on=['rid'], how='left')
    pre = pre.set_index(['uid'])

    mIPIP = {
        'name': 'mini-IPIP',
        'type': 'Likert-5',
        'scales': ['extra', 'agree', 'consc', 'neuro', 'openn'],
        'qs': [
            { 'index':  1, 'name': 'extra-1', 'reverse': False, 'scale': 'extra'},
            { 'index':  2, 'name': 'agree-1', 'reverse': False, 'scale': 'agree'},
            { 'index':  3, 'name': 'consc-1', 'reverse': False, 'scale': 'consc'},
            { 'index':  4, 'name': 'neuro-1', 'reverse': False, 'scale': 'neuro'},
            { 'index':  5, 'name': 'openn-1', 'reverse': False, 'scale': 'openn'},
            { 'index':  6, 'name': 'extra-2', 'reverse':  True, 'scale': 'extra'},
            { 'index':  7, 'name': 'agree-2', 'reverse':  True, 'scale': 'agree'},
            { 'index':  8, 'name': 'consc-2', 'reverse':  True, 'scale': 'consc'},
            { 'index':  9, 'name': 'neuro-2', 'reverse':  True, 'scale': 'neuro'},
            { 'index': 10, 'name': 'openn-2', 'reverse':  True, 'scale': 'openn'},
            { 'index': 11, 'name': 'extra-3', 'reverse': False, 'scale': 'extra'},
            { 'index': 12, 'name': 'agree-3', 'reverse': False, 'scale': 'attra'},
            { 'index': 13, 'name': 'consc-3', 'reverse': False, 'scale': 'consc'},
            { 'index': 14, 'name': 'neuro-3', 'reverse': False, 'scale': 'neuro'},
            { 'index': 15, 'name': 'openn-3', 'reverse':  True, 'scale': 'openn'},
            { 'index': 16, 'name': 'extra-4', 'reverse':  True, 'scale': 'extra'},
            { 'index': 17, 'name': 'agree-4', 'reverse':  True, 'scale': 'agree'},
            { 'index': 18, 'name': 'consc-4', 'reverse':  True, 'scale': 'consc'},
            { 'index': 19, 'name': 'neuro-4', 'reverse':  True, 'scale': 'neuro'},
            { 'index': 20, 'name': 'openn-4', 'reverse':  True, 'scale': 'openn'},
        ]
    }

    rIPIP = pre.iloc[pre.index.notnull(), 10:30]
    l5 = {'Strongly disagree': 1, 'Disagree': 2, 'Neutral': 3, 'Agree': 4, 'Strongly agree': 5}
    rIPIP = rIPIP.applymap(lambda s: l5.get(s) if s in l5 else s)

    sIPIP = parseScales(mIPIP, rIPIP)

    accounts = getAccounts(campaign, campaign['waves'][str(6)])
    survey = pd.merge(accounts[['uid', 'treatment']], sIPIP, on=['uid'], how='right')

    return survey



def parseSurvey():
    pre = pd.read_csv('./survey/21-tuesg-pre-test-survey.csv', sep=',')
    pre = pre.rename(columns = {'Respondent ID': 'rid'})
    premap = pd.read_csv('./survey/mapping-pre-test-survey-account.csv', sep=',')

    pre = pd.merge(pre, premap, on=['rid'], how='left')
    pre = pre.set_index(['uid'])

    mIPIP = {
        'name': 'mini-IPIP',
        'type': 'Likert-5',
        'scales': ['extra', 'agree', 'consc', 'neuro', 'openn'],
        'qs': [
            { 'index':  1, 'name': 'extra-1', 'reverse': False, 'scale': 'extra'},
            { 'index':  2, 'name': 'agree-1', 'reverse': False, 'scale': 'agree'},
            { 'index':  3, 'name': 'consc-1', 'reverse': False, 'scale': 'consc'},
            { 'index':  4, 'name': 'neuro-1', 'reverse': False, 'scale': 'neuro'},
            { 'index':  5, 'name': 'openn-1', 'reverse': False, 'scale': 'openn'},
            { 'index':  6, 'name': 'extra-2', 'reverse':  True, 'scale': 'extra'},
            { 'index':  7, 'name': 'agree-2', 'reverse':  True, 'scale': 'agree'},
            { 'index':  8, 'name': 'consc-2', 'reverse':  True, 'scale': 'consc'},
            { 'index':  9, 'name': 'neuro-2', 'reverse':  True, 'scale': 'neuro'},
            { 'index': 10, 'name': 'openn-2', 'reverse':  True, 'scale': 'openn'},
            { 'index': 11, 'name': 'extra-3', 'reverse': False, 'scale': 'extra'},
            { 'index': 12, 'name': 'agree-3', 'reverse': False, 'scale': 'attra'},
            { 'index': 13, 'name': 'consc-3', 'reverse': False, 'scale': 'consc'},
            { 'index': 14, 'name': 'neuro-3', 'reverse': False, 'scale': 'neuro'},
            { 'index': 15, 'name': 'openn-3', 'reverse':  True, 'scale': 'openn'},
            { 'index': 16, 'name': 'extra-4', 'reverse':  True, 'scale': 'extra'},
            { 'index': 17, 'name': 'agree-4', 'reverse':  True, 'scale': 'agree'},
            { 'index': 18, 'name': 'consc-4', 'reverse':  True, 'scale': 'consc'},
            { 'index': 19, 'name': 'neuro-4', 'reverse':  True, 'scale': 'neuro'},
            { 'index': 20, 'name': 'openn-4', 'reverse':  True, 'scale': 'openn'},
        ]
    }

    rIPIP = pre.iloc[pre.index.notnull(), 10:30]
    l5 = {'Strongly disagree': 1, 'Disagree': 2, 'Neutral': 3, 'Agree': 4, 'Strongly agree': 5}
    rIPIP = rIPIP.applymap(lambda s: l5.get(s) if s in l5 else s)

    sIPIP = parseScales(mIPIP, rIPIP)




    post = pd.read_csv('./survey/21-tuesg-post-test-survey.csv', sep=',')
    post = post.rename(columns = {'Respondent ID': 'rid'})
    postmap = pd.read_csv('./survey/mapping-post-test-survey-account.csv', sep=',')

    post = pd.merge(post, postmap, on=['rid'], how='left')
    post = post.set_index(['uid'])

    mDEMO = [
        { 'index': 10, 'name': 'affili', 'q': 'How are you affiliated to TU/e?'},
        { 'index': 12, 'name': 'gender', 'q': 'What is your gender?'},
        { 'index': 13, 'name': 'agegrp', 'q': 'What is your age?'},

        { 'index': 14, 'name': 'impwalk', 'q': 'I have walked more often than usual due to the TU/e Samen Gezond lifestyle program.'},
        { 'index': 15, 'name': 'impphac', 'q': 'I have engaged in more physical activity than usual due to the TU/e Samen Gezond lifestyle program.'},
        { 'index': 16, 'name': 'impdiet', 'q': 'I have improved my diet due to the TU/e Samen Gezond lifestyle program.'},
        { 'index': 17, 'name': 'impsoci', 'q': 'I have been in touch with my colleagues more often than usual due to the TU/e Samen Gezond Lifestyle Program.'},
        { 'index': 18, 'name': 'impmoni', 'q': 'The prospect of winning a Bol.com voucher has motivated me to actively participate in the TU/e Samen Gezond Lifestyle Program.'},
    ]

    iDEMO = post.iloc[post.index.notnull(), [*map(lambda x : x['index'], mDEMO)]]
    iDEMO.columns = [*map(lambda x : x['name'], mDEMO)]

    l5 = {'Strongly disagree': 1, 'Disagree': 2, 'Neutral': 3, 'Agree': 4, 'Strongly agree': 5}
    iDEMO = iDEMO.applymap(lambda s: l5.get(s) if s in l5 else s)

    affiliations = {'I am a student': 'Student', 'I am a Ph.D. candidate': 'Ph.D.', 'I am a staff member': 'Staff', 'I have studied at TU/e': 'Allumnus'}
    iDEMO['affili'] = iDEMO['affili'].map(lambda s: affiliations.get(s) if s in affiliations else 'Other')

    iDEMO['agegrp'] = iDEMO['agegrp'].str.replace(' to ', '-')



    mIMI = {
        'name': 'Intrinsic Motivation Inventory',
        'type': 'Likert-5',
        'scales': ['enjoy'],
        'qs': [
            { 'index':  1, 'name': 'enjoy-1', 'reverse': False, 'scale': 'enjoy'},
            { 'index':  2, 'name': 'enjoy-2', 'reverse': False, 'scale': 'enjoy'},
            { 'index':  3, 'name': 'enjoy-3', 'reverse':  True, 'scale': 'enjoy'},
            { 'index':  4, 'name': 'enjoy-4', 'reverse':  True, 'scale': 'enjoy'},
            { 'index':  5, 'name': 'enjoy-5', 'reverse': False, 'scale': 'enjoy'},
            { 'index':  6, 'name': 'enjoy-6', 'reverse': False, 'scale': 'enjoy'},
            { 'index':  7, 'name': 'enjoy-7', 'reverse': False, 'scale': 'enjoy'},
        ]
    }


    rIMI = post.iloc[post.index.notnull(), 19:26]
    l5 = {'Strongly disagree': 1, 'Disagree': 2, 'Neutral': 3, 'Agree': 4, 'Strongly agree': 5}
    rIMI = rIMI.applymap(lambda s: l5.get(s) if s in l5 else s)

    sIMI = parseScales(mIMI, rIMI)





    mDGS = {
        'name': 'Deferment of Gratification Scale',
        'type': 'Likert-5',
        'scales': ['dgrat'],
        'qs': [
            { 'index':  1, 'name':  'dgrat-1', 'reverse': False, 'scale': 'dgrat'},
            { 'index':  2, 'name':  'dgrat-2', 'reverse': False, 'scale': 'dgrat'},
            { 'index':  3, 'name':  'dgrat-3', 'reverse': False, 'scale': 'dgrat'},
            { 'index':  4, 'name':  'dgrat-4', 'reverse':  True, 'scale': 'dgrat'},
            { 'index':  5, 'name':  'dgrat-5', 'reverse':  True, 'scale': 'dgrat'},
            { 'index':  6, 'name':  'dgrat-6', 'reverse':  True, 'scale': 'dgrat'},
            { 'index':  7, 'name':  'dgrat-7', 'reverse':  True, 'scale': 'dgrat'},
            { 'index':  8, 'name':  'dgrat-8', 'reverse': False, 'scale': 'dgrat'},
            { 'index':  9, 'name':  'dgrat-9', 'reverse':  True, 'scale': 'dgrat'},
            { 'index': 10, 'name': 'dgrat-10', 'reverse':  True, 'scale': 'dgrat'},
            { 'index': 11, 'name': 'dgrat-11', 'reverse': False, 'scale': 'dgrat'},
            { 'index': 12, 'name': 'dgrat-12', 'reverse': False, 'scale': 'dgrat'},
        ]
    }

    rDGS = post.iloc[post.index.notnull(), 26:38]
    l5 = {'Strongly disagree': 1, 'Disagree': 2, 'Neutral': 3, 'Agree': 4, 'Strongly agree': 5}
    rDGS = rDGS.applymap(lambda s: l5.get(s) if s in l5 else s)

    sDGS = parseScales(mDGS, rDGS)




    mBSC = {
        'name': 'Brief Self-Control Survey',
        'type': 'Likert-5',
        'scales': ['sctrl'],
        'qs': [
            { 'index':  1, 'name':  'sctrl-1', 'reverse': False, 'scale': 'sctrl'},
            { 'index':  2, 'name':  'sctrl-2', 'reverse':  True, 'scale': 'sctrl'},
            { 'index':  3, 'name':  'sctrl-3', 'reverse':  True, 'scale': 'sctrl'},
            { 'index':  4, 'name':  'sctrl-4', 'reverse':  True, 'scale': 'sctrl'},
            { 'index':  5, 'name':  'sctrl-5', 'reverse':  True, 'scale': 'sctrl'},
            { 'index':  6, 'name':  'sctrl-6', 'reverse': False, 'scale': 'sctrl'},
            { 'index':  7, 'name':  'sctrl-7', 'reverse':  True, 'scale': 'sctrl'},
            { 'index':  8, 'name':  'sctrl-8', 'reverse': False, 'scale': 'sctrl'},
            { 'index':  9, 'name':  'sctrl-9', 'reverse':  True, 'scale': 'sctrl'},
            { 'index': 10, 'name': 'sctrl-10', 'reverse':  True, 'scale': 'sctrl'},
            { 'index': 11, 'name': 'sctrl-11', 'reverse': False, 'scale': 'sctrl'},
            { 'index': 12, 'name': 'sctrl-12', 'reverse':  True, 'scale': 'sctrl'},
            { 'index': 13, 'name': 'sctrl-13', 'reverse':  True, 'scale': 'sctrl'},
        ]
    }

    rBSC = post.iloc[post.index.notnull(), 38:51]
    l5 = {'Strongly disagree': 1, 'Disagree': 2, 'Neutral': 3, 'Agree': 4, 'Strongly agree': 5}
    rBSC = rBSC.applymap(lambda s: l5.get(s) if s in l5 else s)

    sBSC = parseScales(mBSC, rBSC)



    rRTI = post.iloc[post.index.notnull(), 51:61]
    rRTI.replace(re.compile('.*€4.*'), 1, inplace=True)
    rRTI.replace(re.compile('.*€0.25.*'), 0, inplace=True)


    rRTI['riska'] = rRTI.sum(axis=1) / 10
    sRTI = rRTI['riska']




    survey = pd.concat([iDEMO, sIMI, sDGS, sBSC, sRTI], axis=1)
    survey = pd.merge(survey, sIPIP, on=['uid'], how='left')
    accounts = getAccounts(campaign, campaign['waves'][str(6)])
    survey = pd.merge(accounts[['uid', 'treatment']], survey, on=['uid'], how='right')


    return survey


def parseScales(meta, rQ):
    c = 0
    if meta['type'] == 'Likert-7':
        c = 4
    elif meta['type'] == 'Likert-5':
        c = 3


    iQ = pd.DataFrame(columns=[*map(lambda x : x['name'], meta['qs'])], index=rQ.index)

    for i, col in enumerate(rQ.columns):
        q = next(r for r in meta['qs'] if r['index'] == i + 1)

        if q:
            if rQ[col].dtype == 'object':
                d = pd.to_numeric(rQ[col].apply(lambda x: ''.join(re.findall('(\d+)', str(x)))), errors='coerce')
            else:
                d = pd.to_numeric(rQ[col], errors='coerce')

            if q['reverse']:
                iQ[q['name']] = d - c
            else:
                iQ[q['name']] = c - d


    Q = pd.DataFrame(columns=meta['scales'], index=rQ.index)

    for s in meta['scales']:
        qs = [*map(lambda x : x['name'], list(filter(lambda x: x['scale'] == s, meta['qs'])))]
        Q[s] = iQ[qs].mean(axis=1)

    return Q

# End of basic functions
